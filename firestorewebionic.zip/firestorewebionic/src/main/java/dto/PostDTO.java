package dto;

import lombok.Data;

@Data
public class PostDTO {
    private String id;
    private String nombre;
    private String latitud;
    private String longitud;
}
